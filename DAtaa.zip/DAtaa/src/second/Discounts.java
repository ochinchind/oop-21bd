package second;

public enum Discounts {
	No, Yes, DoubleYes
}
