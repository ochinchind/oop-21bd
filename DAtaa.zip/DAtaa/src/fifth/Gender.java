package fifth;

public enum Gender {
	B, G,
}
