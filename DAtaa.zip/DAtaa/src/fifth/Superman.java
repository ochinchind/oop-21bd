package fifth;

public class Superman extends Person {
	
	public Superman() {
		
	}
	public Superman(Gender gender, int age) {
		super(gender, age);
	}
	
	public void runFast() {
		
	}
	
	

}
