package fourth;

public class Course {
	String name;
	int numOfCredits;
	
	public Course() {
		
	}
	public Course(String name, int numOfCredits) {
		this.name = name;
		this.numOfCredits=numOfCredits;
	}
	
	public String getName() {
		return name;
	}
	

}
