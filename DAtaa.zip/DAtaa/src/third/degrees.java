package third;

public enum degrees {
	C, F
}
