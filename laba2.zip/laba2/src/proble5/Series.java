package proble5;

public class Series {
	Circuit alb;
}
