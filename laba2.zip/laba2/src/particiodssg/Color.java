package particiodssg;

public enum Color {
RED, BLACK,
}
