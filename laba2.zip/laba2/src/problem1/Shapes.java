package problem1;

public abstract class Shapes {
	
	public abstract double Volume();
	public abstract double surfaceArea();
	
	
}
